
$("#yoou").css("display","none");
$(".gongju").click(function(){
	$("#yoou").css("display","block");
});
$(".guanbi").click(function(){
	$("#yoou").css("display","none");
});
//留言板 1
function fasong() {
	var text = document.getElementById('text');
	var box = document.getElementById('box');
	if (text.value == "") return false;
	else {
		var p = document.createElement('p');
		var now = new Date();
		p.innerHTML = text.value + " 【" + now.toLocaleTimeString() + "】";
		box.insertBefore(p, box.firstElementChild);
	}
}
//留言板 2
function zxc() {
	alert("你看看你-----（小可爱）");
}
//计算机 1
function jsj(fooc) {
	var n1 = parseInt(document.getElementById('n1').value);
	var n2 = parseInt(document.getElementById('n2').value);
	var n3 = document.getElementById('n3');
	if (isNaN(n1) || isNaN(n2)) {
		alert('请输入数字！');
	}
	n3.value = fooc(n1, n2);
}

function jia(n1, n2) {
	return n1 + n2;
}

function jian(n1, n2) {
	return n1 - n2;
}

function cheng(n1, n2) {
	return n1 * n2;
}

function chu(n1, n2) {
	if (n2 == 0) {
		alert('除数不能为零');
		return false;
	} else return n1 / n2;
}
//计算机 2
//时间表 1
var xzsj = new Date();
var wuyi = new Date("2021/5/1");
var duanwu = new Date("2020/6/25");
var guoqing = new Date("2020/10/1");
var zhongqiu = new Date("2020/10/1");
var yuandan = new Date("2021/1/1");
var chunjie = new Date("2021/2/12");
var xzsj1 = document.getElementById('xzsj');
var wuyi1 = document.getElementById('wuyi');
var duanwu1 = document.getElementById('duanwu');
var guoqing1 = document.getElementById('guoqing');
var zhongqiu1 = document.getElementById('zhongqiu');
var yuandan1 = document.getElementById('yuandan');
var chunjie1 = document.getElementById('chunjie');
var juli1 = wuyi - xzsj;
var juli2 = duanwu - xzsj;
var juli3 = guoqing - xzsj;
var juli4 = zhongqiu - xzsj;
var juli5 = yuandan - xzsj;
var juli6 = chunjie - xzsj;
xzsj1.innerHTML = "现在时间";
setInterval(function() {
	var time = new Date();
	var year = time.getFullYear();
	var month = time.getMonth() + 1;
	var day = time.getDate();
	var shi = checktime(time.getHours());
	var fen = checktime(time.getMinutes());
	var miao = checktime(time.getSeconds());

	function checktime(i) {
		if (i < 10) return "0" + i;
		return i;
	}
	xzsj1.innerHTML = "当前时间 " + year + " 年 " + month + " 月 " + day + " 日 " + shi + ":" + fen + ":" + miao;
}, 1000);
wuyi1.innerHTML = "劳动节还有-" + Math.round(juli1 / (60 * 60 * 24 * 1000)) + "-天";
duanwu1.innerHTML = "端午节还有-" + Math.round(juli2 / (60 * 60 * 24 * 1000)) + "-天";
guoqing1.innerHTML = "国庆节还有-" + Math.round(juli3 / (60 * 60 * 24 * 1000)) + "-天";
zhongqiu1.innerHTML = "中秋节还有-" + Math.round(juli4 / (60 * 60 * 24 * 1000)) + "-天";
yuandan1.innerHTML = "元旦还有-" + Math.round(juli5 / (60 * 60 * 24 * 1000)) + "-天";
chunjie1.innerHTML = "新年还有-" + Math.round(juli6 / (60 * 60 * 24 * 1000)) + "-天";
//时间表 2
//天气 1
$.ajax({
	url: 'http://ip.ws.126.net/ipquery?ie=utf-8',
	dataType: "script",
	async: false,
	success: function(data) {
		var url = encodeURI("http://wthrcdn.etouch.cn/weather_mini?city=" + lc);
		$.get({
			url: url,
			dataType: "json",
			async: false,
			success: function(data) {
				var todayWeather = data.data.forecast[0];
				var tomorrowWeather = data.data.forecast[1];
				$("#cweather").html(todayWeather.date.substring(todayWeather.date.indexOf("日") + 1) + " &nbsp&nbsp&nbsp" +
					data.data.wendu + "℃");
				$("#wuhan").html(lc + "：" + todayWeather.type);
				$("#jintian").html(todayWeather.high + "&nbsp&nbsp" + todayWeather.low);
				$("#mingtian").html("明天 :");
				$(".cx").html(tomorrowWeather.high + "&nbsp&nbsp" + tomorrowWeather.low);
			},
		});
	},
});
//天气 2
//选项卡1
$("#yoou>ul:gt(0)").hide();
$(".gan>div").mouseover(function(){
	$("#yoou>ul").eq($(this).index()).show().siblings("ul").hide();
	$(this).css({"color":"pink","background-color":"#03A9F4"}).siblings().css({"color":"white","background-color":"lightblue"});
	
});
// 选项卡2
// 时间表单击变色1
$(".kk").click(function() {
	$(this).css("background-color", "lightpink");
});
// 时间表单击变色2



$(".yi>li").mouseover(function(){
				$(this).css("width","500px");
				$(this).siblings("li").css("width","20px");
			});
			$(".yi>li").mouseout(function(){
				$("ul>dd>li").css("width","120px");
			});


var n = 1;
			$(".xuan>li").eq(0).css("background-color", "lightgreen");
			var ding = setInterval(xyz, 3000);
			//点击圆点事件 
			$(".xuan>li").click(function() {
				clearInterval(ding);
				n = $(this).index() + 1;
				pd();
				ding = setInterval(xyz, 3000);
			});
			//左切图 
			$(".zuo").click(function() {
				clearInterval(ding);
				if (n == 1) {
					n = 5;
					tuwu();
				} else {
					if (n == 2) tuyi();
					if (n == 3) tuer();
					if (n == 4) tusan();
					if (n == 5) tusi();
					n -= 1;
					ding = setInterval(xyz, 3000);
				}
			});
			//右切图 
			$(".you").click(function() {
				clearInterval(ding);
				if (n == 5) {
					n = 1;
					six();
				} else {
					if (n == 4) tuwu();
					if (n == 3) tusi();
					if (n == 2) tusan();
					if (n == 1) tuer();
					n += 1;
				}
				ding = setInterval(xyz, 3000);
			});
			var i=null;
			//鼠标放上停止
			$(".box .tu").mouseenter(function(){
				i=ding;
				clearInterval(ding);
				console.log(ding);
			});
				$(".box .tu").mouseout(function(){
					if(ding==i)
					ding = setInterval(xyz, 3000);
					console.log(ding);
				});
				console.log($(".box"));
			//函数定义部分 
			function pd() {
				if (n == 1) tuyi();
				if (n == 2) tuer();
				if (n == 3) tusan();
				if (n == 4) tusi();
				if (n == 5) tuwu();
				if (n == 6) six();
			}

			function bianse() {
				$(".xuan>li").eq(n - 1).css("background-color", "lightgreen").siblings().css("background-color", "lightblue");
			}

			function tuer() {
				$(".box>.tu").animate({
					left: '-500px'
				}, "1000", bianse);
			}

			function tusan() {
				$(".box>.tu").animate({
					left: '-1000px'
				}, "1000", bianse);
			}

			function tusi() {
				$(".box>.tu").animate({
					left: '-1500px'
				}, "1000", bianse);
			}

			function tuwu() {
				$(".box>.tu").animate({
					left: '-2000px'
				}, "1000", bianse);
			}

			function tuyi() {
				$(".box>.tu").animate({
					left: '0px'
				}, "1000", bianse);
			}

			function xyz() {
				n++;
				pd();
				if (n == 6) n = 1;
			}

			function six() {
				$(".box>.tu").animate({
					left: '-2500px'
				}, "1000", function() {
					$(".box>.tu").css("left", "0");
					bianse();
				});
			}

